
import { Component, OnInit } from '@angular/core';
import { CustumserviceService } from './custumservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
 

export class AppComponent implements OnInit {

  constructor(private _msgService: CustumserviceService) { }
  btnClick1(){
  x:history.back();
  }
  btnClick2(){
    y:history.forward();
    }
  ngOnInit(): void {
    
  }

}

 
function localhost(localhost: any, arg1: number) {
  throw new Error('Function not implemented.');
}

