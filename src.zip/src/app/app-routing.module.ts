import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AngularComponent } from './angular/angular.component';
import { JavaScriptComponent } from './java-script/java-script.component';
import { NodejsComponent } from './nodejs/nodejs.component';

const routes: Routes = [
  {path:"an", component: AngularComponent},
  {path:"js", component: JavaScriptComponent},
  {path:"no", component: NodejsComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
