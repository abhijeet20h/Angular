import { TestBed } from '@angular/core/testing';

import { CustumserviceService } from './custumservice.service';

describe('CustumserviceService', () => {
  let service: CustumserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustumserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
