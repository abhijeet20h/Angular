import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-java-script',
  templateUrl: './java-script.component.html',
  styleUrls: ['./java-script.component.css']
})
export class JavaScriptComponent implements OnInit {
  text="JavaScript"
  constructor() { }

  ngOnInit(): void {
  }

}
